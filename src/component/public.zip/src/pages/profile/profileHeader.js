import React, { Component, Fragment } from 'react';
import './profile.css';
import Grid from '@material-ui/core/Grid';
import Badge from '@material-ui/core/Badge';
import Avatar from '@material-ui/core/Avatar';
import PersonIcon from '@material-ui/icons/Person';
import ChatIcon from '@material-ui/icons/Chat';
import VisibilityIcon from '@material-ui/icons/Visibility';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import axios from 'axios';
import ImageCrop from './crop/imageCrop';
import Classes from './profile.module.css';

import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import CameraAltIcon from '@material-ui/icons/CameraAlt';

import ImgCropPopup from './crop/popup';

import profilePic from './images/profile.png';
import wallpaperPic from './images/walpaper.png';

import dp from './images/dp.jpg';


const StyledBadge = withStyles((theme) => ({
  badge: {
    backgroundColor: '#f50057',
    color: '#f50057',
    boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
    '&::after': {
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      borderRadius: '50%',
      animation: '$ripple 1.2s infinite ease-in-out',
      border: '1px solid currentColor',
      content: '""',
    },
  },
  '@keyframes ripple': {
    '0%': {
      transform: 'scale(.8)',
      opacity: 1,
    },
    '100%': {
      transform: 'scale(2.4)',
      opacity: 0,
    },
  },
}))(Badge);

const SmallAvatar = withStyles((theme) => ({
  root: {
    width: 22,
    height: 22,
    border: `2px solid ${theme.palette.background.paper}`,
  },
}))(Avatar);


const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    '& > *': {
      margin: theme.spacing(1),
    },
  },
 
}));


//open smiple Menu
function SimpleMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <Button aria-controls="simple-menu" aria-haspopup="true" onClick={handleClick}>
      
        <CameraAltIcon className="iconColor initDiable"/> <span className="onHovershow">Update Cover Photo</span>
     
      </Button> 
      <Menu
        id="simple-menu"
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleClose}
      >
        <MenuItem onClick={handleClose}>Select Photo</MenuItem>
        <MenuItem onClick={handleClose}><ImgCropPopup/>  </MenuItem>
        <MenuItem onClick={handleClose}>Remove</MenuItem>
      </Menu>
    </div>
  );
}


class ProfileHeader extends Component {
    
  constructor(props) {
      super(props);
      this.state = {
          selectedFile: null,
          currentProfileImg : null,
          string64Src : "",
          walpaperPic : wallpaperPic,
          imageUrl : 'fgfdg'
      }
  };
  
  onFileChangeHandler = event => {
    console.log("onFileChangeHandler");
    this.setState({
        selectedFile: event.target.files[0],
        loaded: 0,
    })
  }

onClickHandler = (e) => { 
  e.preventDefault();
  console.log("on click handler");
  this.makePostReqWalpaper();
 
}
async  makePostReqWalpaper() {
      if (this.state.selectedFile != null) {
        const data = new FormData()
        data.append('file', this.state.selectedFile);

        let res = await axios.post("http://localhost:8000/upload", data);
            console.log(res);
              console.log(res.data.file.filename);
        this.setState(
          {
            currentProfileImg : await res.data.file.filename
          }
        );
        
    }

    this.makeGetReqToSaveWalpaper();

}

async makeGetReqToSaveWalpaper(){
  console.log("on click save");
  console.log(await this.state.currentProfileImg);

  let param ={
    params: {
      filename:await this.state.currentProfileImg
    }
  }
   let res = await axios.get('http://localhost:8000/image', param);
 
    console.log(res);
    console.log(res.data.image);
    this.setState({
      string64Src :await res.data.image,
      walpaperPic : "data:image/png;base64,"+res.data.image
    });
 
}

handleCrop = async (imageUrl)=>{
  console.log(imageUrl);
  this.setState({
    imageUrl :await imageUrl
  });
  console.log(this.state.imageUrl); 
  
}


  render(){
    return (

      <Fragment>
      <h2>Profile Header</h2>
     
      <Grid container className="section-1" direction="row" justify="center" alignItems="center">
            <Grid item xs={12} className="coverstory">
              <div className="profile-wall">
                         
                        <div className="uploadWrap d-none">
                          <input
                              type="file"
                              name="file" multiple
                              id="profileupload"
                              placeholder="upload photos"
                              onChange={this.onFileChangeHandler} 
                          />
                          <label htmlFor="profileupload">Upload Profile</label>
                           <button type="button" className="" onClick={this.onClickHandler}>save</button>
                         
                        </div>


                      <div className="simpleMenu">
                        <SimpleMenu/>
                      </div>

                    <img className="walpaper--" src={this.state.walpaperPic} alt={this.state.string64Src}/>
                
                    <div className="d-none">
                      <ImageCrop  onCroppedImg={this.handleCrop}/>
                    </div>

              </div>
              
              
              <div className="info-group">
                <div className="part1-icons">
                <StyledBadge
                          overlap="circle"
                          anchorOrigin={{
                            vertical: 'bottom',
                            horizontal: 'right',
                          }}
                          variant="dot"
                        >  
                      <Avatar className={Classes.iconBg}>
                        <PersonIcon className={Classes.iconColor}/>
                      </Avatar>
                  
                      
                   </StyledBadge>           
                    <Avatar className={Classes.iconBg}>
                      <ChatIcon className={Classes.iconColor}/>
                    </Avatar>
                    <Avatar className={Classes.iconBg}>
                      <VisibilityIcon className={Classes.iconColor}/>
                    </Avatar>

                </div>
              </div>
            </Grid>
      </Grid>

      <Grid container className="menu-conainer" direction="row" justify="center" alignItems="center">
            <Grid item md={5}> 
                    <ul className="profile-menu">
                      <li>
                        <a href="02-ProfilePage.html" className="active">Timeline</a>
                      </li>
                      <li>
                        <a href="05-ProfilePage-About.html">About</a>
                      </li>
                      <li>
                        <a href="06-ProfilePage.html">Friends</a>
                      </li>
                    </ul>
            </Grid>

            <Grid item md={2}>
                    <div className={Classes.profileImg}>
                        <img src={profilePic}/>
                    </div>
            </Grid>

            <Grid item md={5}>
                <ul className="profile-menu">
                    <li>
                      <a href="07-ProfilePage-Photos.html">Photos</a>
                    </li>
                    <li>
                      <a href="09-ProfilePage-Videos.html">Videos</a>
                    </li>
                    <li>
                      <div className="more">
                        <span className="dots">...</span>
                        <ul className="more-dropdown more-with-triangle">
                          <li>
                            <a href="#">Report Profile</a>
                          </li>
                          <li>
                            <a href="#">Block Profile</a>
                          </li>
                        </ul>
                      </div>
                    </li>
                  </ul>
            </Grid>

      </Grid>



  </Fragment>



  )};
}

export default ProfileHeader;