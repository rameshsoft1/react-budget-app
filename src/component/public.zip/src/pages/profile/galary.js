import React,{Component} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import GridListTileBar from '@material-ui/core/GridListTileBar';
import ListSubheader from '@material-ui/core/ListSubheader';
import IconButton from '@material-ui/core/IconButton';
import InfoIcon from '@material-ui/icons/Info';
//import tileData from './tileData';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    overflow: 'hidden',
    backgroundColor: theme.palette.background.paper,
  },
  gridList: {
    width: 350,
    height: 450,
  },
  icon: {
    color: 'rgba(255, 255, 255, 0.54)',
  },
}));

/**
 * The example data is structured as follows:
 *
 * import image from 'path/to/image.jpg';
 * [etc...]
 *
 * const tileData = [
 *   {
 *     img: image,
 *     title: 'Image',
 *     author: 'author',
 *   },
 *   {
 *     [etc...]
 *   },
 * ];
 */

 var records =[];



function GalaryList(props) {
    console.log(props.jsonData);
  const classes = useStyles();

  return (
    <div className={classes.root}>
   

      <GridList cellHeight={150} className={classes.gridList}>
        <GridListTile key="Subheader" cols={2} style={{ height: 'auto' }}>
          <ListSubheader component="div">December</ListSubheader>
        </GridListTile>
        {props.jsonData.map((tile) => (
           
          <GridListTile key={tile.id}>
            <img src={tile.thumbnailUrl} alt={tile.title} />
            <GridListTileBar
              title={tile.title}
              subtitle={<span>by: {tile.author}</span>}
              actionIcon={
                <IconButton aria-label={`info about ${tile.title}`} className={classes.icon}>
                  <InfoIcon />
                </IconButton>
              }
            />
          </GridListTile>
        ))}
      </GridList>
    </div>
  );
}


export default class Galary extends Component{
    constructor(props){
        super(props);
        this.state = {
            galaryData : [
                {
                  "albumId": 1,
                  "id": 1,
                  "title": "accusamus beatae ad facilis cum similique qui sunt",
                  "url": "https://via.placeholder.com/600/92c952",
                  "thumbnailUrl": "https://via.placeholder.com/150/92c952"
                },
                {
                  "albumId": 1,
                  "id": 2,
                  "title": "reprehenderit est deserunt velit ipsam",
                  "url": "https://via.placeholder.com/600/771796",
                  "thumbnailUrl": "https://via.placeholder.com/150/771796"
                },
                {
                  "albumId": 1,
                  "id": 3,
                  "title": "officia porro iure quia iusto qui ipsa ut modi",
                  "url": "https://via.placeholder.com/600/24f355",
                  "thumbnailUrl": "https://via.placeholder.com/150/24f355"
                },
                {
                  "albumId": 1,
                  "id": 4,
                  "title": "culpa odio esse rerum omnis laboriosam voluptate repudiandae",
                  "url": "https://via.placeholder.com/600/d32776",
                  "thumbnailUrl": "https://via.placeholder.com/150/d32776"
                },
                {
                  "albumId": 1,
                  "id": 5,
                  "title": "natus nisi omnis corporis facere molestiae rerum in",
                  "url": "https://via.placeholder.com/600/f66b97",
                  "thumbnailUrl": "https://via.placeholder.com/150/f66b97"
                },
                {
                  "albumId": 1,
                  "id": 6,
                  "title": "accusamus ea aliquid et amet sequi nemo",
                  "url": "https://via.placeholder.com/600/56a8c2",
                  "thumbnailUrl": "https://via.placeholder.com/150/56a8c2"
                },
                {
                  "albumId": 1,
                  "id": 7,
                  "title": "officia delectus consequatur vero aut veniam explicabo molestias",
                  "url": "https://via.placeholder.com/600/b0f7cc",
                  "thumbnailUrl": "https://via.placeholder.com/150/b0f7cc"
                },
                {
                  "albumId": 1,
                  "id": 8,
                  "title": "aut porro officiis laborum odit ea laudantium corporis",
                  "url": "https://via.placeholder.com/600/54176f",
                  "thumbnailUrl": "https://via.placeholder.com/150/54176f"
                },
                {
                  "albumId": 1,
                  "id": 9,
                  "title": "qui eius qui autem sed",
                  "url": "https://via.placeholder.com/600/51aa97",
                  "thumbnailUrl": "https://via.placeholder.com/150/51aa97"
                },
                {
                  "albumId": 1,
                  "id": 10,
                  "title": "beatae et provident et ut vel",
                  "url": "https://via.placeholder.com/600/810b14",
                  "thumbnailUrl": "https://via.placeholder.com/150/810b14"
                }]
        }
    }
 componentDidMount(){
    /*fetch('https://jsonplaceholder.typicode.com/photos')
    .then(response => response.json())
    .then(json =>{
      
        this.setState({galaryData:json});

    } );*/
 }
    render(){
        return (
            <div className="box">
                <GalaryList jsonData={this.state.galaryData}/>
            </div>
        );
    }
}