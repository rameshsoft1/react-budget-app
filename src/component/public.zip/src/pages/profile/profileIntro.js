import React, { Component } from 'react';
import './profile.css';
import Avatar from '@material-ui/core/Avatar';
import Classes from './profile.module.css';
import PublicIcon from '@material-ui/icons/Public';
import CastForEducationIcon from '@material-ui/icons/CastForEducation';
import HomeIcon from '@material-ui/icons/Home';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import FavoriteIcon from '@material-ui/icons/Favorite';
import ChatBubbleOutlineIcon from '@material-ui/icons/ChatBubbleOutline';
import Button from '@material-ui/core/Button';

import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';

const useStyles = makeStyles((theme) => ({
     modal: {
       display: 'flex',
       alignItems: 'center',
       justifyContent: 'center',
     },
     paper: {
       backgroundColor: theme.palette.background.paper,
       border: '2px solid #000',
       boxShadow: theme.shadows[5],
       padding: theme.spacing(2, 4, 3),
     },
   }));

    function TransitionsModal() {
     const classes = useStyles();
     const [open, setOpen] = React.useState(false);
   
     const handleOpen = () => {
       setOpen(true);
     };
   
     const handleClose = () => {
       setOpen(false);
     };
   
     return (
       <div>
        

         <Button variant="contained" type="button" onClick={handleOpen}>Edit Details</Button>

         <Modal
           aria-labelledby="transition-modal-title"
           aria-describedby="transition-modal-description"
           className={classes.modal}
           open={open}
           onClose={handleClose}
           closeAfterTransition
           BackdropComponent={Backdrop}
           BackdropProps={{
             timeout: 500,
           }}
         >
           <Fade in={open}>
             <div className={classes.paper}>
               <h2 id="transition-modal-title">Customize Your Intro</h2>
               <p id="transition-modal-description">react-transition-group animates me.</p>
             </div>
           </Fade>
         </Modal>
       </div>
     );
   }

class ProfileIntro extends Component {
     constructor(props){
          super(props);
          this.state = {
               study : 'MCA',
               wentTo : 'SNS college of Technology',
               liveIn : 'Chennai',
               from  : 'Karur',
               married : 'Yes'
          }
     }
  render(){
  return (

        <div  className="section-4 box">
                        <div className="intro iconTxtInline">
                              <Avatar className={Classes.iconBg}>
                                   <PublicIcon className={Classes.iconColor}/>
                              </Avatar>

                            <h4>Intro</h4>

                         </div>
                        <div className="addBio">
                              <div className="justifyCenter">
                                   <ChatBubbleOutlineIcon className={Classes.iconColor}/>
                              </div>
                             

                             <p>Add a short bio to tell people more about yourself.</p>
                             <a href="#">Add Bio</a>
                        </div>

                        <div className="shortIntro">
                            <ul>
                                <li className="iconTxtInline">
                                        <CastForEducationIcon className={Classes.iconColor}/>
                                        <p>Studied <span>{this.state.study}</span></p>
                                </li>
                              
                                <li  className="iconTxtInline">
                                        <CastForEducationIcon className={Classes.iconColor}/>
                                  
                                   <p>Went to <span>{this.state.wentTo}</span></p>
                                </li>
                             
                                <li  className="iconTxtInline">    
                                        <HomeIcon className={Classes.iconColor}/>
                                         <p>Lives in <span>{this.state.liveIn}</span></p>
                                </li>
                                <li  className="iconTxtInline">
                                        <LocationOnIcon className={Classes.iconColor}/>
                                        <p>From <span>{this.state.from}</span></p>
                                </li>
                                <li  className="iconTxtInline">
                               
                                        <FavoriteIcon className={Classes.iconColor}/>
                                        <p>Married <span>{this.state.married}</span></p>   
                                       
                                </li>
                                <li  className="iconTxtInline">
                                    <div className="justifyCenter">
                                        
                                        <TransitionsModal/>
                                     </div>
                                 </li>
                            </ul>
                        </div>


         
        </div>

        


  )};
}

export default ProfileIntro;