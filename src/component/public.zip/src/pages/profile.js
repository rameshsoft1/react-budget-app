import React, { Component, Fragment } from 'react';
import HeaderBar from './header';
import './dashboard/dashboard.css';
import ProfileHeader from './profile/profileHeader';
import Container from '@material-ui/core/Container';
import Grid from '@material-ui/core/Grid';
import ProfileIntro from './profile/profileIntro';
import CreatePost from './profile/createPost';
import Posts from './profile/posts';
import Galary from './profile/galary';

class Profilepage extends Component {
  render() {
    return (



<Fragment>
<HeaderBar/>

<Container fixed>
   <ProfileHeader/>
</Container>

<Container fixed>
  <Grid container>
      <Grid item md={3} className="left-section">
        <ProfileIntro />
      </Grid>
      <Grid item md={5} className="center-section">
          <Posts/>
      </Grid>
      <Grid item md={4} className="right-section">
        <Galary />
      </Grid>
  </Grid>
    

</Container>


</Fragment>
    );
  }
}

export default Profilepage;
